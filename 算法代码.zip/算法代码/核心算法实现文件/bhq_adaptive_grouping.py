#!/usr/bin/env python3
"""
BHQ (桶堆队列) 算法 - 自适应分组版本

此实现演示了使用自适应分组策略的BHQ算法。
该算法通过以下步骤高效地从大型数据集中找到前k个元素：
1. 根据数据特征动态调整分组大小
2. 对每个组进行排序
3. 使用优先队列合并结果

作者：数据可视化专家
日期：2026-04-16
"""

import time
import random
import sys
import psutil
import os
import heapq

class BHQAdaptiveGrouping:
    """
BHQ算法实现（自适应分组策略）
    """
    
    def __init__(self):
        """
        初始化BHQ算法，使用自适应分组策略
        """
        pass
    
    def generate_data(self, size, distribution='random', min_val=0, max_val=1000000):
        """
        生成指定分布的测试数据
        
        参数：
            size: 生成元素数量
            distribution: 数据分布类型 ('random', 'normal', 'skewed', 'duplicate')
            min_val: 随机分布的最小值
            max_val: 随机分布的最大值
            
        返回：
            生成的数据列表
        """
        if size <= 0:
            raise ValueError("数据大小必须为正数")
        
        if distribution == 'random':
            return [random.randint(min_val, max_val) for _ in range(size)]
        elif distribution == 'normal':
            # 生成均值为 (max_val - min_val)/2 的正态分布
            mean = (max_val - min_val) // 2
            std_dev = mean // 3
            return [max(min_val, min(max_val, int(random.normalvariate(mean, std_dev)))) for _ in range(size)]
        elif distribution == 'skewed':
            # 生成左偏分布
            return [random.randint(min_val, min_val + (max_val - min_val) // 10) for _ in range(size // 2)] + \
                   [random.randint(min_val + (max_val - min_val) // 10, max_val) for _ in range(size // 2)]
        elif distribution == 'duplicate':
            # 生成大部分重复值的数据
            base_value = random.randint(min_val, max_val)
            return [base_value for _ in range(size // 2)] + \
                   [random.randint(min_val, max_val) for _ in range(size // 2)]
        else:
            raise ValueError("无效的分布类型。请使用 'random', 'normal', 'skewed' 或 'duplicate'")
    
    def adaptive_grouping(self, data):
        """
        根据数据特征动态确定最佳分组大小
        
        参数：
            data: 输入数据列表
            
        返回：
            最佳分组大小
        """
        data_size = len(data)
        
        # 基于数据大小
        if data_size < 1000:
            return 2  # 小数据，少量分组
        elif data_size < 100000:
            return 4  # 中等数据，适度分组
        elif data_size < 1000000:
            return 8  # 大数据，更多分组
        else:
            # 非常大的数据，使用对数缩放
            return min(100, int(data_size ** 0.5) // 10)
    
    def adaptive_grouping_bhq(self, data, k):
        """
        自适应分组的BHQ算法
        
        参数：
            data: 输入数据列表
            k: 要查找的前k个元素数量
            
        返回：
            元组 (top_k_elements, execution_time, memory_used, comparisons, moves, group_size)
        """
        # 验证输入
        if not data:
            return [], 0, 0, 0, 0, 0
        if k <= 0:
            return [], 0, 0, 0, 0, 0
        if k >= len(data):
            start_time = time.time()
            # 排序前获取内存使用情况
            process = psutil.Process(os.getpid())
            mem_before = process.memory_info().rss / 1024 / 1024
            
            # 使用Heapq算法进行排序（作为基准排序方法）
            sorted_data = self._heapq_sort(data)
            
            # 排序后获取内存使用情况
            mem_after = process.memory_info().rss / 1024 / 1024
            memory_used = mem_after - mem_before
            
            end_time = time.time()
            exec_time = end_time - start_time
            
            return sorted_data, exec_time, memory_used, 0, 0, 1
        
        start_time = time.time()
        
        # 处理前获取内存使用情况
        process = psutil.Process(os.getpid())
        mem_before = process.memory_info().rss / 1024 / 1024
        
        # 步骤1：根据数据特征确定最佳分组大小
        group_size = self.adaptive_grouping(data)
        
        # 步骤2：将数据分成自适应组
        groups = [[] for _ in range(group_size)]
        for i, value in enumerate(data):
            group_idx = i % group_size
            groups[group_idx].append(value)
        
        # 步骤3：对每个组进行降序排序
        sorted_groups = []
        comparisons = 0
        moves = 0
        
        for i, group in enumerate(groups):
            if group:
                # 对组进行降序排序
                # 注意：我们将估算比较次数和移动次数
                # 为简单起见，我们使用基于组大小的粗略估计
                group_size_current = len(group)
                comparisons += group_size_current * (group_size_current - 1) // 2  # 近似快速排序的比较次数
                moves += group_size_current  # 近似移动次数
                
                # 使用Heapq算法进行排序
                sorted_group = self._heapq_sort(group)
                sorted_groups.append((i, sorted_group, 0))  # (group_id, sorted_group, current_index)
        
        # 步骤4：使用优先队列（小顶堆）跟踪最大元素
        heap = []
        
        # 用每个排序组的第一个元素初始化堆
        for group_id, sorted_group, _ in sorted_groups:
            if sorted_group:
                value = sorted_group[0]
                # 推入堆（我们将跟踪最大元素）
                heapq.heappush(heap, (-value, value, group_id, 0))
        
        topk = []
        
        # 步骤5：提取前k个元素
        while heap and len(topk) < k:
            # 弹出最大元素
            neg_val, val, group_id, current_idx = heapq.heappop(heap)
            topk.append(val)
            
            # 找到对应的组并推入下一个元素（如果有）
            for i, (gid, sorted_group, idx) in enumerate(sorted_groups):
                if gid == group_id:
                    next_idx = current_idx + 1
                    if next_idx < len(sorted_group):
                        next_val = sorted_group[next_idx]
                        heapq.heappush(heap, (-next_val, next_val, group_id, next_idx))
                        sorted_groups[i] = (gid, sorted_group, next_idx)
                    break
        
        # 处理后获取内存使用情况
        mem_after = process.memory_info().rss / 1024 / 1024
        memory_used = mem_after - mem_before
        
        end_time = time.time()
        exec_time = end_time - start_time
        
        return topk, exec_time, memory_used, comparisons, moves, group_size
    
    def _heapq_sort(self, data):
        """
        使用Heapq算法对数据进行降序排序
        
        参数：
            data: 要排序的数据列表
            
        返回：
            降序排序后的数据列表
        """
        # 使用heapq模块进行排序
        # 由于heapq默认是小顶堆，我们可以使用负数来实现大顶堆效果
        heap = []
        for item in data:
            heapq.heappush(heap, -item)
        
        # 弹出所有元素并取反，得到降序排序的结果
        sorted_data = []
        while heap:
            sorted_data.append(-heapq.heappop(heap))
        
        return sorted_data
    
    def validate_result(self, data, topk, k):
        """
        通过与暴力方法比较验证结果
        
        参数：
            data: 原始数据
            topk: BHQ算法的结果
            k: 请求的前k个元素数量
            
        返回：
            布尔值，表示结果是否正确
        """
        expected = self._heapq_sort(data)[:k]
        return topk == expected

def main():
    """
    演示自适应分组BHQ算法的主函数
    """
    print("BHQ算法演示 - 自适应分组版本")
    print("=" * 60)
    
    # 获取用户输入
    try:
        data_size = int(input("请输入数据大小（例如：1000000）: "))
        if data_size <= 0:
            raise ValueError("数据大小必须为正数")
        
        distribution = input("请输入数据分布类型（random, normal, skewed, duplicate）: ").lower()
        if distribution not in ['random', 'normal', 'skewed', 'duplicate']:
            raise ValueError("无效的分布类型")
        
        k = int(input("请输入k值（前k个元素的数量）: "))
        if k <= 0:
            raise ValueError("k必须为正数")
        
    except ValueError as e:
        print(f"错误: {e}")
        sys.exit(1)
    
    # 创建BHQ实例
    bhq = BHQAdaptiveGrouping()
    
    # 生成数据
    print(f"\n正在生成 {data_size} 个元素，分布类型为 {distribution}...")
    data = bhq.generate_data(data_size, distribution)
    print(f"数据生成完成。前10个元素: {data[:10]}")
    
    # 运行BHQ算法
    print("\n正在运行BHQ算法，使用自适应分组...")
    topk, exec_time, memory_used, comparisons, moves, group_size = bhq.adaptive_grouping_bhq(data, k)
    
    # 验证结果
    is_valid = bhq.validate_result(data, topk, k)
    
    # 显示结果
    print("\n" + "=" * 60)
    print("结果:")
    print("=" * 60)
    print(f"前 {k} 个元素: {topk}")
    print(f"执行时间: {exec_time:.4f} 秒")
    print(f"内存使用: {memory_used:.2f} MB")
    print(f"估计比较次数: {comparisons}")
    print(f"估计移动次数: {moves}")
    print(f"自适应分组大小: {group_size}")
    print(f"结果验证: {'通过' if is_valid else '失败'}")
    print("=" * 60)
    
    # 性能分析
    print("\n性能分析:")
    print("-" * 60)
    print(f"数据大小: {data_size:,}")
    print(f"自适应分组大小: {group_size}")
    print(f"分布类型: {distribution}")
    print(f"每组元素数: {data_size // group_size}（近似）")
    print(f"时间复杂度: O(n log n) - 主要由每组排序决定")
    print(f"空间复杂度: O(n) - 存储所有数据和排序后的组")
    print("-" * 60)
    
    # 自适应分组策略说明
    print("\n自适应分组策略:")
    print("-" * 60)
    print("分组大小基于数据特征动态确定:")
    print("  - 小数据（< 1,000元素）: 2组")
    print("  - 中等数据（< 100,000元素）: 4组")
    print("  - 大数据（< 1,000,000元素）: 8组")
    print("  - 非常大的数据（≥ 1,000,000元素）: 对数级缩放")
    print("-" * 60)

if __name__ == "__main__":
    main()
