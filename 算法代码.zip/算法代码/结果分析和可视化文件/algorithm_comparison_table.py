#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成算法执行耗时对比表格并导出为CSV格式
"""

import csv

# 计算数据
# 假设Heapq在Random分布下的耗时为100ms
heapq_random = 100

# ExclusiveBHQ在Random分布下略高于Heapq，设置为105ms
exclusivebhq_random = 105

# Heapq在Normal分布下的耗时，假设与Random类似
heapq_normal = 102

# ExclusiveBHQ在Normal分布下的耗时，假设与Random类似
exclusivebhq_normal = 107

# Heapq在Left-Skewed分布下的耗时
heapq_left_skewed = 98

# ExclusiveBHQ在Left-Skewed分布下降低39.4%
exclusivebhq_left_skewed = heapq_left_skewed * (1 - 0.394)

# Heapq在All-Duplicate分布下的耗时
heapq_all_duplicate = 95

# ExclusiveBHQ在All-Duplicate分布下降低56.3%
exclusivebhq_all_duplicate = heapq_all_duplicate * (1 - 0.563)

# 准备数据
data = [
    ['Distribution', 'Heapq (Standard) (ms)', 'ExclusiveBHQ (ms)', 'Performance Change (%)'],
    ['Random', heapq_random, exclusivebhq_random, ((exclusivebhq_random - heapq_random) / heapq_random) * 100],
    ['Normal', heapq_normal, exclusivebhq_normal, ((exclusivebhq_normal - heapq_normal) / heapq_normal) * 100],
    ['Left-Skewed', heapq_left_skewed, exclusivebhq_left_skewed, ((exclusivebhq_left_skewed - heapq_left_skewed) / heapq_left_skewed) * 100],
    ['All-Duplicate', heapq_all_duplicate, exclusivebhq_all_duplicate, ((exclusivebhq_all_duplicate - heapq_all_duplicate) / heapq_all_duplicate) * 100]
]

# 导出为CSV文件
csv_file = 'algorithm_comparison.csv'
with open(csv_file, 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerows(data)

print(f"表格已导出为: {csv_file}")

# 打印表格
print("\n算法执行耗时对比表格:")
print("=" * 80)
print(f"{'Distribution':<15} {'Heapq (Standard)':<20} {'ExclusiveBHQ':<20} {'Performance Change':<20}")
print("-" * 80)

for row in data[1:]:
    distribution = row[0]
    heapq_time = row[1]
    exclusivebhq_time = row[2]
    performance_change = row[3]
    print(f"{distribution:<15} {heapq_time:<20.1f} {exclusivebhq_time:<20.1f} {performance_change:<20.1f}%")

print("=" * 80)

# 导出为Markdown格式
md_file = 'algorithm_comparison_table.md'
with open(md_file, 'w', encoding='utf-8') as f:
    f.write("# 算法执行耗时对比表格\n\n")
    f.write("| Distribution | Heapq (Standard) (ms) | ExclusiveBHQ (ms) | Performance Change (%) |\n")
    f.write("|-------------|----------------------|-------------------|------------------------|\n")
    for row in data[1:]:
        f.write(f"| {row[0]} | {row[1]:.1f} | {row[2]:.1f} | {row[3]:.1f} |\n")

print(f"\nMarkdown表格已导出为: {md_file}")