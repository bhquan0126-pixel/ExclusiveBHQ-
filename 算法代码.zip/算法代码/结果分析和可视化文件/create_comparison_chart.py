#!/usr/bin/env python3
"""
创建类似于示例的分组柱状图
"""

import sys
from PIL import Image, ImageDraw, ImageFont

def create_comparison_chart(output_file, resolution=300):
    """
    创建分组柱状图
    
    Args:
        output_file: 输出图片文件路径
        resolution: 图片分辨率（DPI）
    """
    try:
        # 数据
        distributions = ['Random', 'Normal', 'Left-Skewed', 'All-Duplicate']
        heapq_times = [100.0, 102.0, 98.0, 95.0]
        exclusivebhq_times = [105.0, 107.0, 59.4, 41.5]
        
        # 计算性能变化百分比
        performance_changes = []
        for h, e in zip(heapq_times, exclusivebhq_times):
            change = ((e - h) / h) * 100
            performance_changes.append(change)
        
        # 图表参数
        width = 800
        height = 500
        padding = 50
        bar_width = 60
        group_spacing = 120
        
        # 创建图片
        img = Image.new('RGB', (width, height), color='white')
        draw = ImageDraw.Draw(img)
        
        # 尝试使用不同的字体
        font_paths = [
            'C:/Windows/Fonts/times.ttf',  # Times New Roman
            'C:/Windows/Fonts/arial.ttf',  # Arial
        ]
        
        font = None
        for font_path in font_paths:
            try:
                font = ImageFont.truetype(font_path, 12)
                break
            except Exception:
                continue
        
        # 如果没有找到字体，使用默认字体
        if font is None:
            font = ImageFont.load_default()
        
        # 绘制标题
        title_font = ImageFont.truetype(font_paths[0], 16) if font_paths else font
        draw.text((width//2, padding//2), 'Execution Time Comparison', font=title_font, fill='black', anchor='mm')
        
        # 绘制坐标轴
        draw.line([(padding, padding), (padding, height-padding)], fill='black', width=2)
        draw.line([(padding, height-padding), (width-padding, height-padding)], fill='black', width=2)
        
        # 计算Y轴刻度
        max_value = max(max(heapq_times), max(exclusivebhq_times)) * 1.2
        y_ticks = [0, 25, 50, 75, 100, 125]
        
        # 绘制Y轴刻度和标签
        for tick in y_ticks:
            y = height - padding - (tick / max_value) * (height - 2*padding)
            draw.line([(padding-5, y), (padding, y)], fill='black', width=2)
            draw.text((padding-30, y-6), f'{tick}', font=font, fill='black', anchor='rm')
        
        # 绘制Y轴标签
        draw.text((padding-40, height//2), 'Time (ms)', font=font, fill='black', anchor='mm', angle=90)
        
        # 绘制X轴标签
        for i, dist in enumerate(distributions):
            x = padding + group_spacing/2 + i * group_spacing
            draw.text((x, height-padding+20), dist, font=font, fill='black', anchor='mt')
        
        # 绘制柱状图
        colors = ['#003366', '#A9A9A9']  # 蓝色和灰色
        labels = ['Heapq', 'ExclusiveBHQ']
        
        for i, (dist, h_time, e_time, change) in enumerate(zip(distributions, heapq_times, exclusivebhq_times, performance_changes)):
            # 计算位置
            x = padding + i * group_spacing
            
            # 绘制Heapq柱子
            h_height = (h_time / max_value) * (height - 2*padding)
            h_y = height - padding - h_height
            draw.rectangle([(x, h_y), (x + bar_width, height-padding)], fill=colors[0])
            
            # 绘制ExclusiveBHQ柱子
            e_height = (e_time / max_value) * (height - 2*padding)
            e_y = height - padding - e_height
            draw.rectangle([(x + bar_width + 10, e_y), (x + 2*bar_width + 10, height-padding)], fill=colors[1])
            
            # 标注数值
            draw.text((x + bar_width/2, h_y-10), f'{h_time:.1f}', font=font, fill='black', anchor='mt')
            draw.text((x + bar_width + 10 + bar_width/2, e_y-10), f'{e_time:.1f}', font=font, fill='black', anchor='mt')
            
            # 标注性能变化
            if abs(change) > 5:
                arrow_color = 'green' if change < 0 else 'red'
                arrow_direction = 'up' if change < 0 else 'down'
                
                # 绘制箭头
                arrow_x = x + bar_width + 10 + bar_width/2
                arrow_start = e_y - 20
                arrow_end = arrow_start - 15 if arrow_direction == 'up' else arrow_start + 15
                
                draw.line([(arrow_x, arrow_start), (arrow_x, arrow_end)], fill=arrow_color, width=2)
                if arrow_direction == 'up':
                    draw.polygon([(arrow_x-3, arrow_end), (arrow_x+3, arrow_end), (arrow_x, arrow_end-5)], fill=arrow_color)
                else:
                    draw.polygon([(arrow_x-3, arrow_end), (arrow_x+3, arrow_end), (arrow_x, arrow_end+5)], fill=arrow_color)
                
                # 标注百分比
                change_text = f'{change:.1f}%'
                draw.text((arrow_x, arrow_end-15 if arrow_direction == 'up' else arrow_end+15), change_text, 
                         font=font, fill=arrow_color, anchor='mt')
        
        # 绘制图例
        legend_x = width - padding - 200
        legend_y = padding + 20
        
        for i, (color, label) in enumerate(zip(colors, labels)):
            draw.rectangle([(legend_x, legend_y + i*20), (legend_x + 20, legend_y + i*20 + 15)], fill=color)
            draw.text((legend_x + 30, legend_y + i*20 + 7), label, font=font, fill='black', anchor='lm')
        
        # 绘制水印
        watermark_font = ImageFont.truetype(font_paths[0], 14) if font_paths else font
        draw.text((width//2, height-10), 'algorithm_comparison', font=watermark_font, fill=(150, 150, 150), anchor='mb')
        
        # 保存图片
        img.save(output_file, dpi=(resolution, resolution))
        print(f"成功生成图表: {output_file}")
        return True
        
    except Exception as e:
        print(f"错误: {e}")
        return False

if __name__ == "__main__":
    output_file = "algorithm_comparison_chart.png"
    
    print("正在创建分组柱状图...")
    success = create_comparison_chart(output_file)
    
    if success:
        print(f"图表已保存为: {output_file}")
    else:
        print("创建失败，请检查错误信息")
