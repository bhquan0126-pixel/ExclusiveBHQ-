#!/usr/bin/env python3
"""
使用PIL库生成PNG格式的消融实验雷达图
对比基础堆排序算法（Heapq）与改进算法（ExclusiveBHQ）的性能差异
"""

from PIL import Image, ImageDraw, ImageFont
import math

def create_png_radar_chart():
    """
    创建并保存PNG格式的雷达图
    """
    # 数据配置
    categories = ['Memory Efficiency', 'Skewed-Data Speedup', 'System Stability']
    n_categories = len(categories)
    
    # 算法数据（百分制）
    heapq_data = [60, 45, 70]
    exclusivebhq_data = [85, 98, 92]
    
    # 图像参数
    width, height = 800, 800
    center_x, center_y = width // 2, height // 2
    radius = 300
    
    # 创建图像
    img = Image.new('RGB', (width, height), color='white')
    draw = ImageDraw.Draw(img)
    
    # 尝试加载字体
    try:
        font = ImageFont.truetype('C:/Windows/Fonts/times.ttf', 12)
        title_font = ImageFont.truetype('C:/Windows/Fonts/times.ttf', 16)
        label_font = ImageFont.truetype('C:/Windows/Fonts/times.ttf', 14)
    except:
        # 如果找不到字体，使用默认字体
        font = ImageFont.load_default()
        title_font = font
        label_font = font
    
    # 绘制背景网格
    for angle in range(0, 360, 30):
        rad = math.radians(angle)
        x = center_x + radius * math.cos(rad)
        y = center_y + radius * math.sin(rad)
        draw.line([(center_x, center_y), (x, y)], fill='#CCCCCC', width=1)
    
    # 绘制同心圆
    for r in range(1, 6):
        r_scaled = r * radius / 5
        draw.ellipse([(center_x - r_scaled, center_y - r_scaled), 
                      (center_x + r_scaled, center_y + r_scaled)], 
                     outline='#CCCCCC', width=1)
    
    # 绘制类别标签
    for i, category in enumerate(categories):
        angle = i * 360 / n_categories
        rad = math.radians(angle)
        x = center_x + (radius + 30) * math.cos(rad)
        y = center_y + (radius + 30) * math.sin(rad)
        
        # 调整文本位置
        if angle == 0:
            draw.text((x - len(category)*4, y - 10), category, font=label_font, fill='black')
        elif angle == 180:
            draw.text((x - len(category)*4, y), category, font=label_font, fill='black')
        elif angle < 180:
            draw.text((x, y), category, font=label_font, fill='black')
        else:
            draw.text((x - len(category)*8, y), category, font=label_font, fill='black')
    
    # 绘制Heapq数据
    heapq_points = []
    for i, val in enumerate(heapq_data):
        angle = i * 360 / n_categories
        rad = math.radians(angle)
        r_scaled = val * radius / 100
        x = center_x + r_scaled * math.cos(rad)
        y = center_y + r_scaled * math.sin(rad)
        heapq_points.append((x, y))
    
    # 闭合路径
    heapq_points.append(heapq_points[0])
    draw.line(heapq_points, fill='#1E90FF', width=3)
    
    # 绘制ExclusiveBHQ数据
    exclusivebhq_points = []
    for i, val in enumerate(exclusivebhq_data):
        angle = i * 360 / n_categories
        rad = math.radians(angle)
        r_scaled = val * radius / 100
        x = center_x + r_scaled * math.cos(rad)
        y = center_y + r_scaled * math.sin(rad)
        exclusivebhq_points.append((x, y))
    
    # 闭合路径
    exclusivebhq_points.append(exclusivebhq_points[0])
    draw.line(exclusivebhq_points, fill='#FF8C00', width=3)
    draw.polygon(exclusivebhq_points, fill='#FF8C00', outline='#FF8C00', width=3)
    
    # 绘制数据点
    for point in heapq_points[:-1]:
        draw.ellipse([(point[0]-5, point[1]-5), (point[0]+5, point[1]+5)], fill='#1E90FF')
    
    for point in exclusivebhq_points[:-1]:
        draw.ellipse([(point[0]-5, point[1]-5), (point[0]+5, point[1]+5)], fill='#FF8C00')
    
    # 添加标题
    draw.text((center_x, 50), 'Ablation Study: Heapq vs ExclusiveBHQ', 
              font=title_font, fill='black', anchor='mm')
    
    # 添加图例
    legend_x, legend_y = 600, 600
    draw.rectangle([(legend_x, legend_y), (legend_x+20, legend_y+10)], fill='#1E90FF')
    draw.text((legend_x+30, legend_y), 'Heapq (Baseline)', font=font, fill='black')
    
    draw.rectangle([(legend_x, legend_y+20), (legend_x+20, legend_y+30)], fill='#FF8C00')
    draw.text((legend_x+30, legend_y+20), 'ExclusiveBHQ (Proposed)', font=font, fill='black')
    
    # 添加注释
    draw.text((100, 700), 'Heapq: Balanced performance but lacks targeted optimization', 
              font=font, fill='black')
    draw.text((100, 720), 'ExclusiveBHQ: Excellent performance in skewed data and stability', 
              font=font, fill='black')
    
    # 保存为PNG格式
    output_file = 'ablation_study_radar.png'
    img.save(output_file, dpi=(300, 300))
    
    print(f"雷达图已保存为: {output_file}")
    print("图片分辨率: 300 DPI")
    print("图片尺寸: 800x800像素")

if __name__ == "__main__":
    print("正在生成PNG格式的消融实验雷达图...")
    create_png_radar_chart()
