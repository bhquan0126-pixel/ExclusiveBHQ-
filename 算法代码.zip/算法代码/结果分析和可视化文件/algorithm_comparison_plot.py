#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
使用Seaborn库创建算法执行耗时对比柱状图
"""

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial']  # 设置中文字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 计算数据
# 假设Heapq在Random分布下的耗时为100ms
heapq_random = 100

# ExclusiveBHQ在Random分布下略高于Heapq，设置为105ms
exclusivebhq_random = 105

# Heapq在Normal分布下的耗时，假设与Random类似
heapq_normal = 102

# ExclusiveBHQ在Normal分布下的耗时，假设与Random类似
exclusivebhq_normal = 107

# Heapq在Left-Skewed分布下的耗时
heapq_left_skewed = 98

# ExclusiveBHQ在Left-Skewed分布下降低39.4%
exclusivebhq_left_skewed = heapq_left_skewed * (1 - 0.394)

# Heapq在All-Duplicate分布下的耗时
heapq_all_duplicate = 95

# ExclusiveBHQ在All-Duplicate分布下降低56.3%
exclusivebhq_all_duplicate = heapq_all_duplicate * (1 - 0.563)

# 准备数据
data = {
    'Distribution': ['Random', 'Normal', 'Left-Skewed', 'All-Duplicate'] * 2,
    'Algorithm': ['Heapq (Standard)', 'Heapq (Standard)', 'Heapq (Standard)', 'Heapq (Standard)',
                  'ExclusiveBHQ', 'ExclusiveBHQ', 'ExclusiveBHQ', 'ExclusiveBHQ'],
    'Time (ms)': [heapq_random, heapq_normal, heapq_left_skewed, heapq_all_duplicate,
                  exclusivebhq_random, exclusivebhq_normal, exclusivebhq_left_skewed, exclusivebhq_all_duplicate]
}

# 创建DataFrame
df = pd.DataFrame(data)

# 设置Seaborn风格
sns.set_style("whitegrid")
sns.set_context("paper", font_scale=1.2)

# 创建图表
plt.figure(figsize=(10, 6))

# 绘制分组柱状图
ax = sns.barplot(
    x='Distribution',
    y='Time (ms)',
    hue='Algorithm',
    data=df,
    palette={'Heapq (Standard)': '#3498db', 'ExclusiveBHQ': '#95a5a6'},
    edgecolor='black',
    linewidth=1
)

# 添加标题和标签
plt.title('不同分布下算法执行耗时对比', fontsize=16, fontweight='bold')
plt.xlabel('数据分布', fontsize=14)
plt.ylabel('执行耗时 (ms)', fontsize=14)

# 调整图例位置
plt.legend(title='算法', loc='upper right', fontsize=12)

# 添加网格线
plt.grid(axis='y', linestyle='--', alpha=0.7)

# 调整布局
plt.tight_layout()

# 保存图表为高分辨率图片
plt.savefig('algorithm_comparison.png', dpi=300, bbox_inches='tight')
plt.savefig('algorithm_comparison.pdf', dpi=300, bbox_inches='tight')

# 显示图表
plt.show()

print("图表已保存为: algorithm_comparison.png")
print("图表已保存为: algorithm_comparison.pdf")

# 打印数据
print("\n数据详情:")
print(df)