#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
使用ASCII字符创建算法执行耗时对比柱状图
"""

# 计算数据
# 假设Heapq在Random分布下的耗时为100ms
heapq_random = 100

# ExclusiveBHQ在Random分布下略高于Heapq，设置为105ms
exclusivebhq_random = 105

# Heapq在Normal分布下的耗时，假设与Random类似
heapq_normal = 102

# ExclusiveBHQ在Normal分布下的耗时，假设与Random类似
exclusivebhq_normal = 107

# Heapq在Left-Skewed分布下的耗时
heapq_left_skewed = 98

# ExclusiveBHQ在Left-Skewed分布下降低39.4%
exclusivebhq_left_skewed = heapq_left_skewed * (1 - 0.394)

# Heapq在All-Duplicate分布下的耗时
heapq_all_duplicate = 95

# ExclusiveBHQ在All-Duplicate分布下降低56.3%
exclusivebhq_all_duplicate = heapq_all_duplicate * (1 - 0.563)

# 准备数据
data = {
    'Random': {'Heapq (Standard)': heapq_random, 'ExclusiveBHQ': exclusivebhq_random},
    'Normal': {'Heapq (Standard)': heapq_normal, 'ExclusiveBHQ': exclusivebhq_normal},
    'Left-Skewed': {'Heapq (Standard)': heapq_left_skewed, 'ExclusiveBHQ': exclusivebhq_left_skewed},
    'All-Duplicate': {'Heapq (Standard)': heapq_all_duplicate, 'ExclusiveBHQ': exclusivebhq_all_duplicate}
}

# 计算最大高度
max_value = max(max(values.values()) for values in data.values())
scale = 30 / max_value  # 缩放因子，使最大高度为30

# 定义颜色
colors = {
    'Heapq (Standard)': '#',  # 深蓝色
    'ExclusiveBHQ': '+'       # 浅灰色
}

# 打印图表
print("=" * 100)
print("不同分布下算法执行耗时对比")
print("=" * 100)
print("\n")

# 打印图例
print("图例:")
for algo, color in colors.items():
    print(f"  {color} : {algo}")
print("\n")

# 打印柱状图
for distribution, values in data.items():
    print(f"{distribution}:")
    print("-" * 80)
    
    # 打印Heapq (Standard)柱子
    heapq_height = int(values['Heapq (Standard)'] * scale)
    print(f"Heapq (Standard): {values['Heapq (Standard)']:.1f}ms")
    print(f"  {colors['Heapq (Standard)'] * heapq_height}")
    
    # 打印ExclusiveBHQ柱子
    exclusivebhq_height = int(values['ExclusiveBHQ'] * scale)
    print(f"ExclusiveBHQ:    {values['ExclusiveBHQ']:.1f}ms")
    print(f"  {colors['ExclusiveBHQ'] * exclusivebhq_height}")
    
    # 计算并打印性能提升
    improvement = ((values['Heapq (Standard)'] - values['ExclusiveBHQ']) / values['Heapq (Standard)']) * 100
    if improvement > 0:
        print(f"  性能提升: {improvement:.1f}%")
    else:
        print(f"  性能下降: {abs(improvement):.1f}%")
    print("\n")

# 打印数据表格
print("=" * 100)
print("数据详情")
print("=" * 100)
print(f"{'分布':<15} {'Heapq (Standard)':<20} {'ExclusiveBHQ':<20} {'性能变化':<15}")
print("-" * 100)

for distribution, values in data.items():
    heapq_val = values['Heapq (Standard)']
    exclusivebhq_val = values['ExclusiveBHQ']
    change = ((exclusivebhq_val - heapq_val) / heapq_val) * 100
    change_str = f"{change:.1f}%"
    print(f"{distribution:<15} {heapq_val:<20.1f} {exclusivebhq_val:<20.1f} {change_str:<15}")

print("=" * 100)