#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
使用Seaborn库生成符合学术论文发表标准的对比柱状图
"""

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# 设置字体为Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 准备数据
distributions = ['Random', 'Normal', 'Left-Skewed', 'All-Duplicate']
heapq_times = [100.0, 102.0, 98.0, 95.0]
exclusivebhq_times = [105.0, 107.0, 59.4, 41.5]

# 计算性能提升百分比
performance_changes = [
    ((exclusivebhq_times[0] - heapq_times[0]) / heapq_times[0]) * 100,
    ((exclusivebhq_times[1] - heapq_times[1]) / heapq_times[1]) * 100,
    ((exclusivebhq_times[2] - heapq_times[2]) / heapq_times[2]) * 100,
    ((exclusivebhq_times[3] - heapq_times[3]) / heapq_times[3]) * 100
]

# 准备DataFrame
data = {
    'Distribution': distributions * 2,
    'Algorithm': ['Heapq'] * 4 + ['ExclusiveBHQ'] * 4,
    'Execution Time (ms)': heapq_times + exclusivebhq_times
}
df = pd.DataFrame(data)

# 设置Seaborn风格
sns.set_style("ticks")
sns.set_context("paper", font_scale=1.2)

# 创建图表
plt.figure(figsize=(10, 6))

# 绘制分组柱状图
ax = sns.barplot(
    x='Distribution',
    y='Execution Time (ms)',
    hue='Algorithm',
    data=df,
    palette={'Heapq': '#003366', 'ExclusiveBHQ': '#A9A9A9'},
    edgecolor='black',
    linewidth=1
)

# 去除顶部和右侧边框
sns.despine(top=True, right=True)

# 添加标题和标签
plt.title('Execution Time Comparison by Distribution Type', fontsize=16, fontweight='bold')
plt.xlabel('Distribution Type', fontsize=14)
plt.ylabel('Execution Time (ms)', fontsize=14)

# 调整图例位置
plt.legend(title='Algorithm', loc='upper right', fontsize=12)

# 添加网格线
plt.grid(axis='y', linestyle='--', alpha=0.7)

# 在ExclusiveBHQ数据中显著提升的柱子上方标注性能提升百分比
for i, (dist, change) in enumerate(zip(distributions, performance_changes)):
    if change < -30:  # 只标注性能提升显著的（下降超过30%）
        # 获取ExclusiveBHQ柱子的高度
        height = exclusivebhq_times[i]
        # 添加标注
        plt.text(
            i + 0.25,  # x坐标（ExclusiveBHQ柱子的位置）
            height + 2,  # y坐标（柱子顶部上方）
            f'{change:.1f}%',  # 标注文本
            ha='center',  # 水平对齐
            va='bottom',  # 垂直对齐
            color='red',  # 红色字体
            fontsize=11,  # 字体大小
            fontweight='bold'  # 粗体
        )

# 调整布局
plt.tight_layout()

# 保存图表为高分辨率图片
output_png = 'algorithm_comparison_academic.png'
output_pdf = 'algorithm_comparison_academic.pdf'
plt.savefig(output_png, dpi=300, bbox_inches='tight')
plt.savefig(output_pdf, dpi=300, bbox_inches='tight')

# 显示图表
plt.show()

print(f"图表已保存为: {output_png}")
print(f"图表已保存为: {output_pdf}")

# 打印数据
print("\n数据详情:")
print(df)