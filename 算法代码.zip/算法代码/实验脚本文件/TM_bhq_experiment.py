#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BHQ Top-K 算法性能测试 - 两千万数据规模
"""

import time
import psutil
import random

# ==================== 算法实现 ====================

class ListNode:
    """链表节点类"""
    def __init__(self, value, group_id):
        self.value = value
        self.group_id = group_id
        self.next = None



class AdaptiveBHQTopK:
    """自适应BHQ Top-K算法实现"""
    def __init__(self, data, k):
        self.data = data
        self.k = k
        self.comparisons = 0
        self.moves = 0
    
    def adaptive_grouping(self):
        """自适应分组"""
        if len(self.data) < 1000:
            return 2  # 数据量小时分2组
        elif len(self.data) < 100000:
            return 4  # 中等数据量分4组
        else:
            return min(10000, len(self.data) // 1000)  # 大数据量最多分10000组
    
    def select_topk(self):
        """选择Top-K元素"""
        if not self.data:
            return []
        
        if self.k <= 0:
            return []
        
        if self.k >= len(self.data):
            sorted_data = sorted(self.data, reverse=True)
            self.comparisons = len(self.data) * (len(self.data) - 1) // 2
            self.moves = len(self.data) - 1
            return sorted_data
        
        # 1. 自适应分组
        group_count = self.adaptive_grouping()
        group_size = len(self.data) // group_count + 1
        groups = [[] for _ in range(group_count)]
        
        for i, value in enumerate(self.data):
            group_idx = i % group_count
            groups[group_idx].append(value)
        
        # 2. 构建降序链表
        group_heads = []
        for group_id, group_data in enumerate(groups):
            if not group_data:
                continue
            
            # 降序排序
            sorted_group = sorted(group_data, reverse=True)
            self.comparisons += len(sorted_group) * (len(sorted_group) - 1) // 2
            self.moves += len(sorted_group) - 1
            
            # 构建链表
            head = ListNode(sorted_group[0], group_id)
            current = head
            for value in sorted_group[1:]:
                current.next = ListNode(value, group_id)
                current = current.next
            group_heads.append(head)
        
        # 3. 构建候选池（小顶堆）
        import heapq
        heap = []
        for head in group_heads:
            # 使用负数构建小顶堆，模拟大顶堆
            heapq.heappush(heap, (-head.value, head.value, head.group_id, head))
            self.comparisons += 1
        
        # 4. 选择Top-K
        result = []
        while heap and len(result) < self.k:
            # 取出最大值
            neg_val, val, group_id, node = heapq.heappop(heap)
            result.append(val)
            
            # 从同组取下一个元素
            if node.next:
                next_node = node.next
                heapq.heappush(heap, (-next_node.value, next_node.value, next_node.group_id, next_node))
                self.comparisons += 1
        
        return result
    
    def get_stats(self):
        """获取统计信息"""
        return self.comparisons, self.moves

# ==================== 辅助函数 ====================

def heapq_topk(data, k):
    """使用heapq实现Top-K"""
    import heapq
    return heapq.nlargest(k, data)

def quickselect_topk(data, k):
    """使用QuickSelect算法实现Top-K"""
    if not data or k <= 0:
        return []
    if k >= len(data):
        return sorted(data, reverse=True)
    
    # 复制数据以避免修改原数据
    data_copy = data.copy()
    
    def partition(left, right, pivot_idx):
        """分区函数"""
        pivot = data_copy[pivot_idx]
        # 将pivot移到末尾
        data_copy[pivot_idx], data_copy[right] = data_copy[right], data_copy[pivot_idx]
        store_idx = left
        for i in range(left, right):
            if data_copy[i] > pivot:  # 降序排列
                data_copy[store_idx], data_copy[i] = data_copy[i], data_copy[store_idx]
                store_idx += 1
        # 将pivot移到正确位置
        data_copy[right], data_copy[store_idx] = data_copy[store_idx], data_copy[right]
        return store_idx
    
    def select(left, right, k_smallest):
        """选择第k_smallest个元素"""
        if left == right:
            return data_copy[left]
        # 随机选择pivot
        pivot_idx = random.randint(left, right)
        pivot_idx = partition(left, right, pivot_idx)
        if k_smallest == pivot_idx:
            return data_copy[k_smallest]
        elif k_smallest < pivot_idx:
            return select(left, pivot_idx - 1, k_smallest)
        else:
            return select(pivot_idx + 1, right, k_smallest)
    
    # 找到第k大的元素
    k_th_largest = select(0, len(data_copy) - 1, k - 1)
    # 收集所有大于等于第k大元素的元素
    topk = [x for x in data_copy if x > k_th_largest]
    # 收集等于第k大元素的元素
    equals = [x for x in data_copy if x == k_th_largest]
    # 确保总共有k个元素
    topk.extend(equals[:k - len(topk)])
    # 降序排序
    topk.sort(reverse=True)
    return topk

def bucket_topk(data, k):
    """使用Bucket Top-K算法实现Top-K"""
    if not data or k <= 0:
        return []
    if k >= len(data):
        return sorted(data, reverse=True)
    
    # 确定值域范围
    min_val = min(data)
    max_val = max(data)
    
    # 创建桶
    bucket_count = min(10000, len(data))  # 最多10000个桶
    bucket_size = (max_val - min_val + 1) / bucket_count
    buckets = [[] for _ in range(bucket_count)]
    
    # 将数据放入桶中
    for value in data:
        bucket_idx = min(int((value - min_val) / bucket_size), bucket_count - 1)
        buckets[bucket_idx].append(value)
    
    # 从高到低遍历桶，收集Top-K元素
    topk = []
    for i in range(bucket_count - 1, -1, -1):
        if buckets[i]:
            # 对桶内元素排序
            bucket_sorted = sorted(buckets[i], reverse=True)
            # 计算需要从该桶中取多少元素
            need = k - len(topk)
            if need > 0:
                take = min(need, len(bucket_sorted))
                topk.extend(bucket_sorted[:take])
                if len(topk) == k:
                    break
    
    return topk

# ==================== 数据生成 ====================

def generate_random_data(size, seed=None):
    """生成随机数据"""
    if seed is not None:
        random.seed(seed)
    return [random.randint(1, 1000000) for _ in range(size)]

def generate_normal_data(size, seed=None):
    """生成正态分布数据"""
    if seed is not None:
        random.seed(seed)
    # 模拟正态分布
    data = []
    for _ in range(size):
        # 生成近似正态分布的随机数
        value = int(random.gauss(500000, 150000))
        value = max(1, min(1000000, value))
        data.append(value)
    return data

def generate_skewed_data(size, seed=None):
    """生成右倾斜分布数据"""
    if seed is not None:
        random.seed(seed)
    data = []
    for _ in range(size):
        # 生成右倾斜分布的随机数
        value = int(random.paretovariate(3)) * 10000
        value = max(1, min(1000000, value))
        data.append(value)
    return data

def generate_left_skewed_data(size, seed=None):
    """生成左倾斜分布数据"""
    if seed is not None:
        random.seed(seed)
    data = []
    for _ in range(size):
        # 生成左倾斜分布的随机数
        value = 1000000 - int(random.paretovariate(3)) * 10000
        value = max(1, min(1000000, value))
        data.append(value)
    return data

def generate_duplicate_data(size, seed=None):
    """生成全重复值数据"""
    if seed is not None:
        random.seed(seed)
    base_value = random.randint(1, 1000000)
    return [base_value for _ in range(size)]

# ==================== 性能测试 ====================
def test_algorithm(algorithm, data, k, name):
    """测试单个算法的性能"""
    start_time = time.time()
    if name == "Heapq":
        result = heapq_topk(data, k)
        comparisons = 0  # heapq 的比较次数难以统计
        moves = 0
    elif name == "QuickSelect":
        result = quickselect_topk(data, k)
        comparisons = 0  # QuickSelect 的比较次数难以统计
        moves = 0
    elif name == "Bucket Top-K":
        result = bucket_topk(data, k)
        comparisons = 0  # Bucket Top-K 的比较次数难以统计
        moves = 0
    else:
        algo = AdaptiveBHQTopK(data, k)
        result = algo.select_topk()
        comparisons, moves = algo.get_stats()
    end_time = time.time()
    
    # 生成排序后的数据
    sorted_data = sorted(data, reverse=True)
    
    return {
        "name": name,
        "result": result,
        "sorted_data": sorted_data,
        "time": end_time - start_time,
        "comparisons": comparisons,
        "moves": moves
    }

# ==================== 主测试函数 ====================
def run_experiments():
    """运行多维度实验"""
    print("========================================")
    print("开始 BHQ Top-K 算法性能测试")
    print("========================================")
    
    # 测试数据规模
    data_sizes = [20000000]  # 2000万
    k_values = [1000, 10000]  # 只测试大K值
    
    # 算法列表
    algorithms = [
        # "Heapq",  # 注释掉原有算法
        # "Adaptive BHQ",  # 注释掉原有算法
        "QuickSelect",
        "Bucket Top-K"
    ]
    
    # 数据分布列表
    data_distributions = {
        "随机分布": generate_random_data,
        "正态分布": generate_normal_data,
        "右倾斜分布": generate_skewed_data,
        "左倾斜分布": generate_left_skewed_data,
        "全重复值": generate_duplicate_data
    }
    
    # 重复运行次数
    repeat_times = 3
    
    # 测试每种数据规模
    for size in data_sizes:
        print(f"\n开始测试数据规模: {size}...")
        try:
            # 为每种数据规模创建独立的输出文件
            output_file = f"TM_bhq_experiment_{size}_results.txt"
            output = []
            output.append("=" * 100)
            output.append(f"BHQ Top-K 算法性能测试 - 数据规模: {size}")
            output.append("=" * 100)
            output.append(f"测试时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
            output.append(f"重复运行次数: {repeat_times}")
            output.append("")
            
            # 测试每种数据分布
            for dist_name, dist_func in data_distributions.items():
                print(f"  处理数据分布: {dist_name}")
                try:
                    output.append(f"\n数据分布: {dist_name}")
                    output.append("-" * 80)
                    
                    # 生成数据
                    print(f"    正在生成{dist_name}数据...")
                    if dist_name == "正态分布":
                        import numpy as np
                        np.random.seed(42)
                        data = np.random.normal(500000, 150000, size).astype(int)
                        data = np.clip(data, 1, 1000000).tolist()
                    else:
                        data = dist_func(size, seed=42)
                    print(f"    数据生成完成，内存使用: {psutil.Process().memory_info().rss / 1024 / 1024:.2f} MB")
                    
                    # 输出数据摘要
                    output.append(f"  数据规模: {size} 个元素")
                    output.append(f"  数据范围: {min(data)} ~ {max(data)}")
                    output.append(f"  数据摘要: {data[:5]}...{data[-5:]} ")
                    
                    # 测试不同K值
                    for k in k_values:
                        if k > size:
                            continue
                        
                        print(f"    测试 K = {k}")
                        output.append(f"\nK = {k}:")
                        output.append("  " + "-" * 76)
                        
                        # 为每种算法存储多次运行的结果
                        algo_results = {}
                        for algo_name in algorithms:
                            algo_results[algo_name] = {
                                "times": [],
                                "comparisons": [],
                                "moves": [],
                                "memory": []
                            }
                        
                        # 重复运行多次
                        for i in range(repeat_times):
                            print(f"      运行 {i+1}/{repeat_times}")
                            output.append(f"  运行 {i+1}/{repeat_times}:")
                            
                            # 测试每种算法
                            for algo_name in algorithms:
                                # 获取当前进程
                                process = psutil.Process(os.getpid())
                                
                                try:
                                    # 执行算法
                                    print(f"        测试 {algo_name}...")
                                    result = test_algorithm(algo_name, data, k, algo_name)
                                    
                                    # 记录内存使用
                                    memory_usage = process.memory_info().rss / 1024 / 1024  # MB
                                    
                                    # 存储结果
                                    algo_results[algo_name]["times"].append(result['time'])
                                    algo_results[algo_name]["comparisons"].append(result['comparisons'])
                                    algo_results[algo_name]["moves"].append(result['moves'])
                                    algo_results[algo_name]["memory"].append(memory_usage)
                                    
                                    # 输出单次运行结果（转换为毫秒）
                                    time_ms = result['time'] * 1000
                                    output.append(f"    {algo_name}: 时间={time_ms:.2f}ms, 内存={memory_usage:.2f}MB")
                                    print(f"        {algo_name} 完成，时间={time_ms:.2f}ms")
                                    
                                finally:
                                    # 释放内存
                                    del process
                                    import gc
                                    gc.collect()
                        
                        # 计算平均值并输出表格
                        print("    计算平均结果...")
                        output.append("  " + "-" * 76)
                        output.append("  平均结果:")
                        output.append("  +----------------+-------------+---------------+---------------+---------------+")
                        output.append("  | 算法名称       | 平均时间(ms) | 平均比较次数  | 平均移动次数  | 平均内存(MB)  |")
                        output.append("  +----------------+-------------+---------------+---------------+---------------+")
                        
                        for algo_name in algorithms:
                            avg_time = sum(algo_results[algo_name]["times"]) / repeat_times
                            avg_time_ms = avg_time * 1000  # 转换为毫秒
                            avg_comparisons = sum(algo_results[algo_name]["comparisons"]) / repeat_times
                            avg_moves = sum(algo_results[algo_name]["moves"]) / repeat_times
                            avg_memory = sum(algo_results[algo_name]["memory"]) / repeat_times
                            
                            output.append(f"  | {algo_name:<14} | {avg_time_ms:11.2f} | {int(avg_comparisons):13d} | {int(avg_moves):13d} | {avg_memory:11.2f} |")
                        
                        output.append("  +----------------+-------------+---------------+---------------+---------------+")
                        
                        # 输出Top-K结果
                        print("    验证结果正确性...")
                        output.append("  Top-K 结果:")
                        for algo_name in algorithms:
                            algo_result = test_algorithm(algo_name, data, k, algo_name)['result']
                            output.append(f"    {algo_name}: {algo_result}")
                        
                        # 验证结果正确性
                        output.append("  结果验证:")
                        # 获取QuickSelect的结果作为参考
                        ref_result = test_algorithm("QuickSelect", data, k, "QuickSelect")['result']
                        for algo_name in algorithms:
                            algo_result = test_algorithm(algo_name, data, k, algo_name)['result']
                            is_correct = sorted(algo_result, reverse=True) == sorted(ref_result, reverse=True)
                            output.append(f"    {algo_name}: {'正确' if is_correct else '错误'}")
                except Exception as e:
                    print(f"  测试{dist_name}时出现错误: {e}")
                    output.append(f"  测试错误: {str(e)}")
                finally:
                    # 释放数据内存
                    if 'data' in locals():
                        del data
                    import gc
                    gc.collect()
                    print(f"  {dist_name}数据已释放，内存使用: {psutil.Process().memory_info().rss / 1024 / 1024:.2f} MB")
            
            # 写入文件
            print(f"\n写入测试结果到文件...")
            with open(output_file, "w", encoding="utf-8") as f:
                f.write("\n".join(output))
            
            # 输出到控制台
            print("========================================")
            print(f"BHQ Top-K 算法性能测试 - 数据规模: {size}")
            print("========================================")
            print(f"测试完成！结果已写入 {output_file}")
            print("========================================")
        except Exception as e:
            print(f"测试数据规模 {size} 时出现错误: {e}")
            import traceback
            traceback.print_exc()
        finally:
            # 释放所有内存
            import gc
            gc.collect()
            print(f"数据规模 {size} 测试完成，内存已释放")
    
    print("\n========================================")
    print("所有测试完成")
    print("========================================")

# ==================== 运行测试 ====================
if __name__ == "__main__":
    import os
    try:
        run_experiments()
    except Exception as e:
        print(f"测试过程中出现错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # 最终释放所有内存
        import gc
        gc.collect()
        print("内存已释放，测试结束")