#!/usr/bin/env python3
"""
测试BHQ算法的固定分组和自适应分组版本
验证排序结果的正确性
"""

import sys
import os

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from bhq_original_grouping import BHQFixedGrouping
from bhq_adaptive_grouping import BHQAdaptiveGrouping

def test_bhq_algorithms():
    """
    测试BHQ算法的两种实现
    """
    print("BHQ算法测试")
    print("=" * 60)
    
    # 测试参数
    test_cases = [
        (1000, 'random', 10),
        (1000, 'normal', 5),
        (1000, 'skewed', 15),
        (1000, 'duplicate', 8),
        (5000, 'random', 20),
    ]
    
    # 测试固定分组版本
    print("\n测试固定分组版本:")
    print("-" * 60)
    
    fixed_bhq = BHQFixedGrouping(group_size=4)
    fixed_pass_count = 0
    
    for data_size, distribution, k in test_cases:
        print(f"测试: 数据大小={data_size}, 分布={distribution}, k={k}")
        
        # 生成数据
        data = fixed_bhq.generate_data(data_size, distribution)
        
        # 运行算法
        topk, exec_time, memory_used, _, _ = fixed_bhq.fixed_grouping_bhq(data, k)
        
        # 验证结果
        is_valid = fixed_bhq.validate_result(data, topk, k)
        
        if is_valid:
            print(f"  [通过] - 执行时间: {exec_time:.4f}秒, 内存: {memory_used:.2f}MB")
            fixed_pass_count += 1
        else:
            print(f"  [失败]")
    
    # 测试自适应分组版本
    print("\n测试自适应分组版本:")
    print("-" * 60)
    
    adaptive_bhq = BHQAdaptiveGrouping()
    adaptive_pass_count = 0
    
    for data_size, distribution, k in test_cases:
        print(f"测试: 数据大小={data_size}, 分布={distribution}, k={k}")
        
        # 生成数据
        data = adaptive_bhq.generate_data(data_size, distribution)
        
        # 运行算法
        topk, exec_time, memory_used, _, _, group_size = adaptive_bhq.adaptive_grouping_bhq(data, k)
        
        # 验证结果
        is_valid = adaptive_bhq.validate_result(data, topk, k)
        
        if is_valid:
            print(f"  [通过] - 执行时间: {exec_time:.4f}秒, 内存: {memory_used:.2f}MB, 分组大小: {group_size}")
            adaptive_pass_count += 1
        else:
            print(f"  [失败]")
    
    # 汇总结果
    print("\n" + "=" * 60)
    print("测试结果汇总:")
    print("=" * 60)
    print(f"固定分组版本: {fixed_pass_count}/{len(test_cases)} 通过")
    print(f"自适应分组版本: {adaptive_pass_count}/{len(test_cases)} 通过")
    
    if fixed_pass_count == len(test_cases) and adaptive_pass_count == len(test_cases):
        print("\n所有测试通过！")
        return True
    else:
        print("\n部分测试失败！")
        return False

if __name__ == "__main__":
    print("开始测试BHQ算法...")
    success = test_bhq_algorithms()
    
    if success:
        print("\n测试完成，所有算法实现正确！")
    else:
        print("\n测试完成，存在问题需要修复！")
        sys.exit(1)
