"""
BHQ Top-K算法性能测试脚本（大规模数据）

测试一亿个数的排序性能，包括：
- 暴力排序
- Heapq模块
- 原始BHQ算法
- 自适应BHQ算法

输出结果到文本文件
"""

import time
import heapq
import random
import psutil
import os
import gc

# 确保psutil库已安装
try:
    import psutil
except ImportError:
    print("请先安装psutil库: pip install psutil")
    exit(1)

# 确保numpy库已安装（用于生成大规模数据）
try:
    import numpy as np
except ImportError:
    print("请先安装numpy库: pip install numpy")
    exit(1)

class ListNode:
    """链表节点类"""
    def __init__(self, value, group_id):
        self.value = value
        self.group_id = group_id
        self.next = None



class AdaptiveBHQTopK:
    """自适应BHQ Top-K算法实现"""
    def __init__(self, data, k):
        self.data = data
        self.k = k
        self.comparison_count = 0
        self.move_count = 0
    
    def adaptive_grouping(self):
        """自适应分组"""
        if not self.data:
            return []
        
        # 计算数据倾斜度
        sorted_data = sorted(self.data)
        self.comparison_count += len(self.data) * (len(self.data) - 1) // 2
        
        if len(self.data) < 4:
            return [self.data]
        
        q1_idx = len(self.data) // 4
        q3_idx = 3 * len(self.data) // 4
        q1 = sorted_data[q1_idx]
        q3 = sorted_data[q3_idx]
        iqr = q3 - q1
        
        # 根据IQR判断倾斜度
        if iqr == 0:
            # 数据高度倾斜，使用更多分组
            num_groups = 4
        else:
            # 计算数据范围
            data_range = max(self.data) - min(self.data)
            if data_range == 0:
                num_groups = 2
            else:
                # 计算变异系数
                mean = sum(self.data) / len(self.data)
                cv = (iqr / mean) if mean != 0 else 0
                
                if cv < 0.2:
                    # 低倾斜度
                    num_groups = 2
                elif cv < 0.5:
                    # 中等倾斜度
                    num_groups = 3
                else:
                    # 高倾斜度
                    num_groups = 4
        
        # 执行分组
        groups = [[] for _ in range(num_groups)]
        for i, value in enumerate(self.data):
            group_idx = i % num_groups
            groups[group_idx].append(value)
        
        return groups
    
    def build_sorted_linked_list(self, group, group_id):
        """构建降序链表"""
        # 降序排序
        self.comparison_count += len(group) * (len(group) - 1) // 2
        sorted_group = sorted(group, reverse=True)
        
        # 构建链表
        dummy = ListNode(None, group_id)
        current = dummy
        for value in sorted_group:
            current.next = ListNode(value, group_id)
            current = current.next
            self.move_count += 1
        
        return dummy.next
    
    def select_topk(self):
        """核心Top-K选择逻辑"""
        if self.k <= 0 or not self.data:
            return []
        
        if self.k >= len(self.data):
            self.comparison_count += len(self.data) * (len(self.data) - 1) // 2
            return sorted(self.data, reverse=True)
        
        # 自适应分组
        groups = self.adaptive_grouping()
        
        # 为每个分组构建降序链表
        all_heads = []
        for i, group in enumerate(groups):
            if group:
                head = self.build_sorted_linked_list(group, i)
                all_heads.append(head)
        
        # 初始化候选池（使用最小堆，存储负值以模拟最大堆）
        heap = []
        for head in all_heads:
            if head:
                heapq.heappush(heap, (-head.value, head.value, head.group_id, head))
                self.comparison_count += 1
        
        # 收集Top-K结果
        result = []
        while heap and len(result) < self.k:
            # 取出当前最大值
            neg_val, val, group_id, current_node = heapq.heappop(heap)
            result.append(val)
            self.comparison_count += 1
            
            # 从同一组取下一个元素
            if current_node.next:
                next_node = current_node.next
                heapq.heappush(heap, (-next_node.value, next_node.value, next_node.group_id, next_node))
                self.comparison_count += 1
                self.move_count += 1
        
        return result
    
    def get_stats(self):
        """返回统计信息"""
        return {
            "comparison_count": self.comparison_count,
            "move_count": self.move_count
        }

def generate_random_data(size):
    """生成随机数据"""
    if size > 1000000:
        # 对于大规模数据，使用numpy生成
        return np.random.randint(0, 1000000, size).tolist()
    else:
        return [random.randint(0, 1000000) for _ in range(size)]

def generate_skewed_data(size):
    """生成极端分布数据（向高位数集中）"""
    if size > 1000000:
        # 对于大规模数据，使用numpy生成
        # 80%的数据集中在900000-1000000之间
        high_values = np.random.randint(900000, 1000000, int(size * 0.8))
        low_values = np.random.randint(0, 900000, int(size * 0.2))
        return np.concatenate([high_values, low_values]).tolist()
    else:
        # 80%的数据集中在900000-1000000之间
        high_values = [random.randint(900000, 1000000) for _ in range(int(size * 0.8))]
        low_values = [random.randint(0, 900000) for _ in range(int(size * 0.2))]
        return high_values + low_values

def 暴力排序_topk(data, k):
    """暴力排序取Top-K"""
    start_time = time.time()
    # 排序并取前K个
    sorted_data = sorted(data, reverse=True)
    topk = sorted_data[:k]
    end_time = time.time()
    return topk, end_time - start_time, sorted_data

def heapq_topk(data, k):
    """使用heapq模块取Top-K"""
    start_time = time.time()
    # 使用nlargest函数
    topk = heapq.nlargest(k, data)
    # 生成排序后的数据
    sorted_data = sorted(data, reverse=True)
    end_time = time.time()
    stats = {
        "comparison_count": 0,  # Heapq的比较次数难以统计
        "move_count": 0
    }
    return topk, end_time - start_time, stats, sorted_data



def adaptive_bhq_topk(data, k):
    """使用自适应BHQ算法取Top-K"""
    start_time = time.time()
    # 创建算法实例并执行
    bhq = AdaptiveBHQTopK(data, k)
    topk = bhq.select_topk()
    # 生成排序后的数据
    sorted_data = sorted(data, reverse=True)
    end_time = time.time()
    stats = bhq.get_stats()
    return topk, end_time - start_time, stats, sorted_data

def quickselect_topk(data, k):
    """使用QuickSelect算法取Top-K"""
    start_time = time.time()
    if not data or k <= 0:
        topk = []
    elif k >= len(data):
        topk = sorted(data, reverse=True)
    else:
        # 复制数据以避免修改原数据
        data_copy = data.copy()
        
        def partition(left, right, pivot_idx):
            """分区函数"""
            pivot = data_copy[pivot_idx]
            # 将pivot移到末尾
            data_copy[pivot_idx], data_copy[right] = data_copy[right], data_copy[pivot_idx]
            store_idx = left
            for i in range(left, right):
                if data_copy[i] > pivot:  # 降序排列
                    data_copy[store_idx], data_copy[i] = data_copy[i], data_copy[store_idx]
                    store_idx += 1
            # 将pivot移到正确位置
            data_copy[right], data_copy[store_idx] = data_copy[store_idx], data_copy[right]
            return store_idx
        
        def select(left, right, k_smallest):
            """选择第k_smallest个元素"""
            if left == right:
                return data_copy[left]
            # 随机选择pivot
            pivot_idx = random.randint(left, right)
            pivot_idx = partition(left, right, pivot_idx)
            if k_smallest == pivot_idx:
                return data_copy[k_smallest]
            elif k_smallest < pivot_idx:
                return select(left, pivot_idx - 1, k_smallest)
            else:
                return select(pivot_idx + 1, right, k_smallest)
        
        # 找到第k大的元素
        k_th_largest = select(0, len(data_copy) - 1, k - 1)
        # 收集所有大于等于第k大元素的元素
        topk = [x for x in data_copy if x > k_th_largest]
        # 收集等于第k大元素的元素
        equals = [x for x in data_copy if x == k_th_largest]
        # 确保总共有k个元素
        topk.extend(equals[:k - len(topk)])
        # 降序排序
        topk.sort(reverse=True)
    # 生成排序后的数据
    sorted_data = sorted(data, reverse=True)
    end_time = time.time()
    stats = {
        "comparison_count": 0,  # QuickSelect 的比较次数难以统计
        "move_count": 0
    }
    return topk, end_time - start_time, stats, sorted_data

def bucket_topk(data, k):
    """使用Bucket Top-K算法取Top-K"""
    start_time = time.time()
    if not data or k <= 0:
        topk = []
    elif k >= len(data):
        topk = sorted(data, reverse=True)
    else:
        # 确定值域范围
        min_val = min(data)
        max_val = max(data)
        
        # 创建桶
        bucket_count = min(10000, len(data))  # 最多10000个桶
        bucket_size = (max_val - min_val + 1) / bucket_count
        buckets = [[] for _ in range(bucket_count)]
        
        # 将数据放入桶中
        for value in data:
            bucket_idx = min(int((value - min_val) / bucket_size), bucket_count - 1)
            buckets[bucket_idx].append(value)
        
        # 从高到低遍历桶，收集Top-K元素
        topk = []
        for i in range(bucket_count - 1, -1, -1):
            if buckets[i]:
                # 对桶内元素排序
                bucket_sorted = sorted(buckets[i], reverse=True)
                # 计算需要从该桶中取多少元素
                need = k - len(topk)
                if need > 0:
                    take = min(need, len(bucket_sorted))
                    topk.extend(bucket_sorted[:take])
                    if len(topk) == k:
                        break
    # 生成排序后的数据
    sorted_data = sorted(data, reverse=True)
    end_time = time.time()
    stats = {
        "comparison_count": 0,  # Bucket Top-K 的比较次数难以统计
        "move_count": 0
    }
    return topk, end_time - start_time, stats, sorted_data

def original_bhq_topk(data, k):
    """使用原始BHQ算法取Top-K"""
    start_time = time.time()
    if not data or k <= 0:
        topk = []
    elif k >= len(data):
        topk = sorted(data, reverse=True)
    else:
        # 简单分组（固定4组）
        num_groups = 4
        groups = [[] for _ in range(num_groups)]
        for i, value in enumerate(data):
            group_idx = i % num_groups
            groups[group_idx].append(value)
        
        # 为每个分组构建降序链表
        all_heads = []
        for i, group in enumerate(groups):
            if group:
                sorted_group = sorted(group, reverse=True)
                dummy = ListNode(None, i)
                current = dummy
                for value in sorted_group:
                    current.next = ListNode(value, i)
                    current = current.next
                all_heads.append(dummy.next)
        
        # 初始化候选池（使用最小堆，存储负值以模拟最大堆）
        heap = []
        for head in all_heads:
            if head:
                heapq.heappush(heap, (-head.value, head.value, head.group_id, head))
        
        # 收集Top-K结果
        topk = []
        while heap and len(topk) < k:
            # 取出当前最大值
            neg_val, val, group_id, current_node = heapq.heappop(heap)
            topk.append(val)
            
            # 从同一组取下一个元素
            if current_node.next:
                next_node = current_node.next
                heapq.heappush(heap, (-next_node.value, next_node.value, next_node.group_id, next_node))
    # 生成排序后的数据
    sorted_data = sorted(data, reverse=True)
    end_time = time.time()
    stats = {
        "comparison_count": 0,  # 原始BHQ的比较次数难以统计
        "move_count": 0
    }
    return topk, end_time - start_time, stats, sorted_data

def run_experiments():
    """运行性能测试"""
    print("========================================")
    print("开始 BHQ Top-K 算法性能测试（大规模数据）")
    print("========================================")
    
    # 输出文件路径
    output_file = "bhq_experiment_large_results.txt"
    
    # 检查系统内存是否足够处理五千万数据
    print("检查系统内存...")
    total_memory = psutil.virtual_memory().total / 1024 / 1024  # MB
    available_memory = psutil.virtual_memory().available / 1024 / 1024  # MB
    print(f"总内存: {total_memory:.2f} MB")
    print(f"可用内存: {available_memory:.2f} MB")
    
    # 估算五千万个整数需要的内存（每个整数约4字节，加上其他开销）
    estimated_memory_needed = 50000000 * 4 / 1024 / 1024 * 2  # 保守估算，乘以2
    print(f"估算需要内存: {estimated_memory_needed:.2f} MB")
    
    if available_memory < estimated_memory_needed:
        print("错误: 系统内存不足，无法处理五千万数据规模！")
        print("终止执行...")
        # 写入错误信息到文件
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("错误: 系统内存不足，无法处理五千万数据规模！\n")
        return
    
    # 打开文件进行写入
    with open(output_file, 'w', encoding='utf-8') as f:
        # 记录开始时间
        start_time = time.time()
        start_timestamp = time.strftime("%Y-%m-%d %H:%M:%S") + "." + str(time.time() % 1)[2:8]
        f.write(f"执行开始时间: {start_timestamp}\n\n")
        
        # 记录初始内存使用
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        f.write(f"初始内存使用: {initial_memory:.2f} MB\n\n")
        print(f"初始内存使用: {initial_memory:.2f} MB")
        
        # 测试数据规模 - 测试五千万个数
        data_sizes = [50000000]  # 五千万个数
        k_values = [10000]  # 只测试K=10000
        
        # 算法列表
        algorithms = [
            ("Heapq", heapq_topk),
            # ("Original BHQ", original_bhq_topk),  # 暂时注释掉，执行时间太长
            # ("Adaptive BHQ", adaptive_bhq_topk),  # 暂时注释掉，执行时间太长
            ("QuickSelect", quickselect_topk),
            ("Bucket Top-K", bucket_topk)
        ]
        
        # 测试不同数据规模
        for size in data_sizes:
            print(f"\n开始测试数据规模: {size}...")
            f.write(f"=============================================\n")
            f.write(f"测试数据规模: {size} 个数\n")
            f.write(f"=============================================\n\n")
            
            # 测试随机分布数据
            print("  处理随机分布数据...")
            f.write(f"\n--- 随机分布数据 ---")
            print("    生成随机分布数据...")
            # 分批次生成数据，避免内存溢出
            batch_size = 10000000  # 每批次1000万
            data = []
            for i in range(0, size, batch_size):
                batch = generate_random_data(min(batch_size, size - i))
                data.extend(batch)
                print(f"    生成批次 {i//batch_size + 1}/{(size + batch_size - 1)//batch_size}，内存使用: {process.memory_info().rss / 1024 / 1024:.2f} MB")
            print(f"    数据生成完成，内存使用: {process.memory_info().rss / 1024 / 1024:.2f} MB")
            f.write(f"数据生成完成，内存使用: {process.memory_info().rss / 1024 / 1024:.2f} MB\n")
            
            # 输出数据摘要
            f.write(f"  数据规模: {size} 个元素\n")
            # 对于一亿数据，只输出前20个和后20个元素
            f.write(f"  原始数据样本: {data[:20]}...{data[-20:]}\n")
            
            # 测试不同K值
            for k in k_values:
                print(f"    测试 K = {k}")
                f.write(f"\nK = {k}:\n")
                
                # 测试不同算法
                for algo_name, algo_func in algorithms:
                    print(f"      测试 {algo_name}...")
                    f.write(f"  {algo_name}:\n")
                    
                    # 记录开始时间
                    algo_start_time = time.time()
                    
                    # 记录开始前的CPU利用率
                    cpu_percent_start = psutil.cpu_percent(interval=0.1)
                    
                    try:
                        # 执行算法
                        if algo_name == "暴力排序":
                            topk, exec_time, sorted_data = algo_func(data, k)
                            f.write(f"    执行时间: {exec_time:.6f} 秒\n")
                        else:
                            topk, exec_time, stats, sorted_data = algo_func(data, k)
                            f.write(f"    执行时间: {exec_time:.6f} 秒\n")
                            f.write(f"    比较次数: {stats['comparison_count']}\n")
                            f.write(f"    移动次数: {stats['move_count']}\n")
                        
                        # 记录结束后的CPU利用率
                        cpu_percent_end = psutil.cpu_percent(interval=0.1)
                        avg_cpu_percent = (cpu_percent_start + cpu_percent_end) / 2
                        f.write(f"    CPU利用率: {avg_cpu_percent:.2f}%\n")
                        
                        # 记录内存使用
                        current_memory = process.memory_info().rss / 1024 / 1024  # MB
                        f.write(f"    内存使用: {current_memory:.2f} MB\n")
                        
                        # 输出Top-K结果和排序后数据
                        f.write(f"    Top-{k} 结果: {topk[:10]}...\n")  # 只输出前10个结果
                        f.write(f"    排序后数据 (前10个): {sorted_data[:10]}\n")
                        
                        # 验证结果正确性（与Heapq对比，因为Heapq是标准库，结果更可靠）
                        if algo_name == "Heapq":
                            reference_result = topk
                        else:
                            # 排序后比较
                            if sorted(topk, reverse=True) == sorted(reference_result, reverse=True):
                                f.write("    结果正确\n")
                            else:
                                f.write("    结果错误\n")
                        
                        print(f"      {algo_name} 完成，时间={exec_time:.6f}秒, CPU={avg_cpu_percent:.2f}%")
                        
                        # 释放内存
                        del topk
                        del sorted_data
                        gc.collect()
                        
                        # 等待系统资源释放
                        time.sleep(1)
                    except Exception as e:
                        print(f"      {algo_name} 执行失败: {str(e)}")
                        f.write(f"    执行失败: {str(e)}\n")
                        # 继续执行下一个算法
                        continue
            
            # 释放内存
            del data
            gc.collect()
            print(f"  随机分布数据测试完成，内存使用: {process.memory_info().rss / 1024 / 1024:.2f} MB")
            f.write(f"随机分布数据测试完成，内存使用: {process.memory_info().rss / 1024 / 1024:.2f} MB\n")
            
            # 测试极端分布数据
            print("  处理极端分布数据...")
            f.write(f"\n--- 极端分布数据（向高位数集中）---\n")
            print("    生成极端分布数据...")
            data = generate_skewed_data(size)
            print(f"    数据生成完成，内存使用: {process.memory_info().rss / 1024 / 1024:.2f} MB")
            f.write(f"数据生成完成，内存使用: {process.memory_info().rss / 1024 / 1024:.2f} MB\n")
            
            # 输出数据摘要
            f.write(f"  数据规模: {size} 个元素\n")
            # 对于一亿数据，只输出前20个和后20个元素
            f.write(f"  原始数据样本: {data[:20]}...{data[-20:]}\n")
            
            # 测试不同K值
            for k in k_values:
                print(f"    测试 K = {k}")
                f.write(f"\nK = {k}:\n")
                
                # 测试不同算法
                for algo_name, algo_func in algorithms:
                    print(f"      测试 {algo_name}...")
                    f.write(f"  {algo_name}:\n")
                    
                    # 记录开始时间
                    algo_start_time = time.time()
                    
                    # 记录开始前的CPU利用率
                    cpu_percent_start = psutil.cpu_percent(interval=0.1)
                    
                    try:
                        # 执行算法
                        if algo_name == "暴力排序":
                            topk, exec_time, sorted_data = algo_func(data, k)
                            f.write(f"    执行时间: {exec_time:.6f} 秒\n")
                        else:
                            topk, exec_time, stats, sorted_data = algo_func(data, k)
                            f.write(f"    执行时间: {exec_time:.6f} 秒\n")
                            f.write(f"    比较次数: {stats['comparison_count']}\n")
                            f.write(f"    移动次数: {stats['move_count']}\n")
                        
                        # 记录结束后的CPU利用率
                        cpu_percent_end = psutil.cpu_percent(interval=0.1)
                        avg_cpu_percent = (cpu_percent_start + cpu_percent_end) / 2
                        f.write(f"    CPU利用率: {avg_cpu_percent:.2f}%\n")
                        
                        # 记录内存使用
                        current_memory = process.memory_info().rss / 1024 / 1024  # MB
                        f.write(f"    内存使用: {current_memory:.2f} MB\n")
                        
                        # 输出Top-K结果和排序后数据
                        f.write(f"    Top-{k} 结果: {topk[:10]}...\n")  # 只输出前10个结果
                        f.write(f"    排序后数据 (前10个): {sorted_data[:10]}\n")
                        
                        # 验证结果正确性（与Heapq对比，因为Heapq是标准库，结果更可靠）
                        if algo_name == "Heapq":
                            reference_result = topk
                        else:
                            # 排序后比较
                            if sorted(topk, reverse=True) == sorted(reference_result, reverse=True):
                                f.write("    结果正确\n")
                            else:
                                f.write("    结果错误\n")
                        
                        print(f"      {algo_name} 完成，时间={exec_time:.6f}秒, CPU={avg_cpu_percent:.2f}%")
                        
                        # 释放内存
                        del topk
                        del sorted_data
                        gc.collect()
                        
                        # 等待系统资源释放
                        time.sleep(1)
                    except Exception as e:
                        print(f"      {algo_name} 执行失败: {str(e)}")
                        f.write(f"    执行失败: {str(e)}\n")
                        # 继续执行下一个算法
                        continue
            
            # 释放内存
            del data
            gc.collect()
            print(f"  极端分布数据测试完成，内存使用: {process.memory_info().rss / 1024 / 1024:.2f} MB")
            f.write(f"极端分布数据测试完成，内存使用: {process.memory_info().rss / 1024 / 1024:.2f} MB\n")
        
        # 记录结束时间
        end_timestamp = time.strftime("%Y-%m-%d %H:%M:%S") + "." + str(time.time() % 1)[2:8]
        f.write(f"\n执行结束时间: {end_timestamp}\n")
        
        # 计算总执行时间
        # 直接使用time.time()的差值
        total_exec_time = time.time() - start_time
        f.write(f"总执行时间: {total_exec_time:.6f} 秒\n")
        
        # 记录最终内存使用
        final_memory = process.memory_info().rss / 1024 / 1024  # MB
        f.write(f"最终内存使用: {final_memory:.2f} MB\n")
        
        # 计算内存变化
        memory_change = final_memory - initial_memory
        f.write(f"内存变化: {memory_change:.2f} MB\n")
        
        print("========================================")
        print(f"大规模测试结果已写入 {output_file}")
        print(f"总执行时间: {total_exec_time:.6f} 秒")
        print(f"内存使用: 初始 {initial_memory:.2f} MB, 最终 {final_memory:.2f} MB")
        print("========================================")
    
    print("\n========================================")
    print("所有测试完成")
    print("========================================")

if __name__ == "__main__":
    run_experiments()
