"""
原创 BHQ Top-K 算法实现
======================

算法概述：
    BHQ (Best Heap Queue) Top-K 算法是一种高效的选择算法，用于从超大规模数据中快速找出
    前 K 个最大的元素。该算法融合了链表存储和小顶堆的优势，实现了高效的 Top-K 选择。

核心创新：
    1. 链式存储结构：每组数据使用单向链表存储，保持降序排列
    2. 动态补数机制：取出最大值后，自动从同组链表补入下一个元素
    3. 小顶堆候选池：使用小顶堆维护候选元素，实现 O(1) 取最大值

算法流程：
    1. 数据分组：将原始数据切分为固定数量的分组
    2. 构建链表：每组内部构建降序单向链表
    3. 初始化候选池：将所有分组的链表头节点放入小顶堆
    4. 核心循环：
       - 取出全局最大值（堆顶）
       - 加入结果集
       - 从对应分组链表取下一个节点补入候选池
       - 重复直到取满 K 个元素

时间复杂度：O(n log n + k log G)，其中 n 为数据规模，k 为目标数量，G 为分组数
空间复杂度：O(n)，用于存储数据和辅助结构

作者：基于用户原创算法思想实现
日期：2026-04-13
"""

import heapq
import time
import psutil
import os


class ListNode:
    """
    单向链表节点类

    用于存储分组内的数据元素，保持降序排列

    属性：
        value: 节点的值
        group_id: 所属分组编号
        next: 指向下一个节点的指针
    """
    def __init__(self, value, group_id):
        """
        初始化链表节点

        Args:
            value: 节点的值
            group_id: 所属分组编号
        """
        self.value = value
        self.group_id = group_id
        self.next = None


class OriginalBHQTopK:
    """
    原创 BHQ Top-K 算法主类

    实现了基于链表存储和小顶堆的 Top-K 选择算法

    属性：
        data: 原始输入数据的副本
        k: 目标 Top-K 值
        group_count: 分组数量
        groups: 分组数据
        group_heads: 各分组的链表头节点
        comparison_count: 比较操作计数器
        move_count: 移动操作计数器
    """

    def __init__(self, data, k, group_count=100):
        """
        初始化 BHQ Top-K 算法实例

        Args:
            data: 输入的数值型数据列表
            k: 需要选取的前 K 个最大元素
            group_count: 分组数量（默认 100）

        Raises:
            ValueError: 当数据为空、数据包含非数值、k 超过数据长度时抛出异常
        """
        # 数据验证
        if not data:
            raise ValueError("数据不能为空")
        if not all(isinstance(item, (int, float)) for item in data):
            raise ValueError("数据必须全部为数值型")
        if k <= 0 or k > len(data):
            raise ValueError(f"k必须在 1~{len(data)} 之间")

        self.data = data.copy()
        self.k = k
        self.group_count = min(group_count, len(data))  # 分组数不超过数据长度
        self.groups = []  # 分组数据
        self.group_heads = []  # 各分组的链表头节点
        self.comparison_count = 0  # 比较次数
        self.move_count = 0  # 移动次数

    def _compare(self, a, b):
        """
        封装比较操作并计数

        Args:
            a: 第一个比较值
            b: 第二个比较值

        Returns:
            bool: 如果 a > b 返回 True，否则返回 False
        """
        self.comparison_count += 1
        return a > b

    def _move(self):
        """
        记录移动操作
        """
        self.move_count += 1

    def split_data(self):
        """
        数据分组：将原始数据切分为固定数量的分组
        """
        # 计算每组的数据量
        items_per_group = (len(self.data) + self.group_count - 1) // self.group_count
        
        # 切分数据
        for i in range(self.group_count):
            start = i * items_per_group
            end = min(start + items_per_group, len(self.data))
            group_data = self.data[start:end]
            self.groups.append(group_data)

    def build_linked_lists(self):
        """
        构建分组降序链表：对每组数据进行降序排序并构建单向链表
        """
        for group_id, group_data in enumerate(self.groups):
            # 对分组数据进行降序排序
            sorted_group = sorted(group_data, reverse=True)
            
            # 构建单向链表
            dummy = ListNode(None, group_id)
            current = dummy
            
            for value in sorted_group:
                new_node = ListNode(value, group_id)
                current.next = new_node
                current = new_node
                self._move()  # 记录移动操作
            
            # 保存链表头节点（跳过 dummy 节点）
            self.group_heads.append(dummy.next)

    def select_topk(self):
        """
        核心 Top-K 选择算法

        Returns:
            list: 前 K 个最大元素的列表（降序）
        """
        # 步骤1：数据分组
        self.split_data()
        
        # 步骤2：构建降序链表
        self.build_linked_lists()
        
        # 步骤3：初始化候选池（小顶堆）
        # 使用小顶堆，存储 (-value, value, group_id, current_node)
        # 存储负值是为了实现最大堆的效果
        heap = []
        
        for head in self.group_heads:
            if head:
                # 存储负值以实现最大堆效果
                heapq.heappush(heap, (-head.value, head.value, head.group_id, head))
                self._move()  # 记录移动操作
        
        # 步骤4：核心循环，取出 Top-K 元素
        topk = []
        
        while len(topk) < self.k and heap:
            # 取出全局最大值（堆顶）
            neg_val, value, group_id, current_node = heapq.heappop(heap)
            self._move()  # 记录移动操作
            
            # 将最大值加入结果集
            topk.append(value)
            
            # 从对应分组链表取下一个节点
            next_node = current_node.next
            
            # 如果有下一个节点，补入候选池
            if next_node:
                heapq.heappush(heap, (-next_node.value, next_node.value, next_node.group_id, next_node))
                self._move()  # 记录移动操作
        
        return topk

    def get_stats(self):
        """
        获取算法执行统计信息

        Returns:
            tuple: (比较次数, 移动次数)
        """
        return self.comparison_count, self.move_count

# ==================== 主函数 ====================
def generate_data_distributions(size):
    """生成多种数据分布"""
    import random
    import numpy as np
    
    # 随机分布
    random_data = [random.randint(1, 1000000) for _ in range(size)]
    
    # 倾斜分布（向高位集中）
    skewed_data = []
    for _ in range(size):
        if random.random() < 0.7:
            # 70%的数据集中在高位
            skewed_data.append(random.randint(800000, 1000000))
        else:
            # 30%的数据在低位
            skewed_data.append(random.randint(1, 200000))
    
    # 高重复数据
    high_duplicate_data = []
    # 生成10个重复值
    base_values = [random.randint(1, 1000000) for _ in range(10)]
    for _ in range(size):
        high_duplicate_data.append(random.choice(base_values))
    
    return {
        "随机分布": random_data,
        "倾斜分布": skewed_data,
        "高重复数据": high_duplicate_data
    }

def compare_with_heapq(data, k):
    """与Python官方heapq.nlargest进行对比"""
    import heapq
    import time
    
    start_time = time.time()
    result = heapq.nlargest(k, data)
    end_time = time.time()
    
    return result, end_time - start_time

def main():
    """
    主函数：运行算法并将结果输出到文件
    """
    # 数据规模
    data_size = 100000  # 10万条数据
    # 测试K值
    k_values = [10, 200]
    
    # 生成多种数据分布
    data_distributions = generate_data_distributions(data_size)
    
    # 构建输出内容
    output = []
    output.append("=" * 80)
    output.append("Original BHQ Top-K 算法性能测试")
    output.append("=" * 80)
    output.append(f"测试数据规模: {data_size} 条")
    output.append("")
    
    # 测试每种数据分布
    for dist_name, data in data_distributions.items():
        output.append(f"\n数据分布: {dist_name}")
        output.append("-" * 60)
        
        # 测试不同K值
        for k in k_values:
            output.append(f"\nK = {k}:")
            
            # 获取当前进程
            process = psutil.Process(os.getpid())
            
            # 开始时间
            start_time = time.time()
            
            try:
                # 创建算法实例
                algo = OriginalBHQTopK(data, k)
                
                # 执行算法
                result = algo.select_topk()
                
                # 结束时间
                end_time = time.time()
                execution_time = end_time - start_time
                
                # 获取统计信息
                comparisons, moves = algo.get_stats()
                
                # 与heapq.nlargest对比
                heapq_result, heapq_time = compare_with_heapq(data, k)
                
                # 验证结果正确性
                is_correct = sorted(result, reverse=True) == sorted(heapq_result, reverse=True)
                
                # 输出结果
                output.append(f"  原始数据样本:")
                output.append(f"    {data[:20]}...{data[-20:]}")  # 显示前20个和后20个数据
                
                output.append(f"  BHQ算法:")
                output.append(f"    执行时间: {execution_time:.6f} 秒")
                output.append(f"    比较次数: {comparisons}")
                output.append(f"    移动次数: {moves}")
                output.append(f"    结果正确: {is_correct}")
                output.append(f"    Top-{k} 结果: {result}")
                
                output.append(f"  Heapq算法:")
                output.append(f"    执行时间: {heapq_time:.6f} 秒")
                output.append(f"    结果正确: {is_correct}")
                output.append(f"    Top-{k} 结果: {heapq_result}")
                
                # 内存使用
                memory_usage = process.memory_info().rss / 1024 / 1024  # MB
                output.append(f"  内存使用: {memory_usage:.2f} MB")
                
            finally:
                # 释放内存
                del process
                # 强制垃圾回收
                import gc
                gc.collect()
    
    # 写入文件
    output_file = "original_bhq_topk_results.txt"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write("\n".join(output))
    
    print(f"Original BHQ Top-K 算法性能测试完成，结果已写入 {output_file}")

if __name__ == "__main__":
    main()