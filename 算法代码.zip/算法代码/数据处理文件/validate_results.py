#!/usr/bin/env python3
"""
结果验证脚本

验证所有算法的输出结果是否一致
"""

import os
import argparse
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('validate_results.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def load_result(file_path):
    """
    加载算法结果
    
    Args:
        file_path: 结果文件路径
    
    Returns:
        算法名称和Top-K结果
    """
    logger.info(f"加载结果文件: {file_path}")
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # 提取算法名称
        algorithm = None
        topk = None
        
        for line in lines:
            line = line.strip()
            if line.startswith('算法:'):
                algorithm = line.split(':', 1)[1].strip()
            elif line.startswith('Top-'):
                # 提取Top-K结果
                topk_str = line.split(':', 1)[1].strip()
                # 解析结果列表
                topk_str = topk_str.replace('[', '').replace(']', '').replace('...', '')
                # 处理np.int32(999999)格式
                topk = []
                for x in topk_str.split(','):
                    x = x.strip()
                    if x:
                        # 提取数字部分
                        if 'np.int32(' in x:
                            num_str = x.replace('np.int32(', '').replace(')', '')
                        else:
                            num_str = x
                        topk.append(int(num_str))
                break
        
        if not algorithm or not topk:
            logger.error(f"无法从文件中提取结果: {file_path}")
            return None, None
        
        logger.info(f"加载成功: {algorithm}, Top-K结果前10个: {topk[:10]}")
        return algorithm, topk
        
    except Exception as e:
        logger.exception(f"加载结果时发生错误: {str(e)}")
        return None, None

def validate_results(result_files):
    """
    验证所有结果是否一致
    
    Args:
        result_files: 结果文件列表
    
    Returns:
        验证是否通过
    """
    logger.info("开始验证结果...")
    
    # 加载所有结果
    results = []
    for file_path in result_files:
        algorithm, topk = load_result(file_path)
        if algorithm and topk:
            results.append((algorithm, topk))
    
    if len(results) < 2:
        logger.error("结果文件数量不足，无法验证")
        return False
    
    # 以第一个结果为参考
    reference_algorithm, reference_topk = results[0]
    logger.info(f"以 {reference_algorithm} 的结果为参考")
    
    # 验证所有结果是否与参考结果一致
    all_consistent = True
    for algorithm, topk in results[1:]:
        if sorted(topk, reverse=True) == sorted(reference_topk, reverse=True):
            logger.info(f"{algorithm} 的结果与 {reference_algorithm} 一致")
        else:
            logger.error(f"{algorithm} 的结果与 {reference_algorithm} 不一致")
            all_consistent = False
    
    if all_consistent:
        logger.info("所有算法的结果一致，验证通过")
    else:
        logger.error("部分算法的结果不一致，验证失败")
    
    return all_consistent

def main():
    """
    主函数
    """
    parser = argparse.ArgumentParser(description='结果验证脚本')
    parser.add_argument('--results', type=str, nargs='+', 
                        default=['results/heapq_results.txt', 'results/quickselect_results.txt', 
                                 'results/bucket_results.txt', 'results/original_bhq_results.txt', 
                                 'results/adaptive_bhq_results.txt'],
                        help='结果文件路径列表')
    parser.add_argument('--log-level', type=str, default='INFO', 
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help='日志级别')
    
    args = parser.parse_args()
    
    # 设置日志级别
    logger.setLevel(getattr(logging, args.log_level))
    
    try:
        # 验证结果
        success = validate_results(args.results)
        
        # 写入验证报告
        with open('validation_report.txt', 'w', encoding='utf-8') as f:
            f.write(f"验证时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"验证结果: {'通过' if success else '失败'}\n")
            f.write(f"验证文件: {', '.join(args.results)}\n")
        
        logger.info(f"验证报告已写入: validation_report.txt")
        return 0 if success else 1
        
    except Exception as e:
        logger.exception(f"执行过程中发生错误: {str(e)}")
        return 1

if __name__ == "__main__":
    import time
    exit(main())
