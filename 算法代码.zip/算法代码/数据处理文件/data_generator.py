#!/usr/bin/env python3
"""
数据生成脚本

生成5000万个符合业务规则的数据样本，并保存为HDF5格式
"""

import os
import time
import argparse
import numpy as np
import h5py
import logging
from tqdm import tqdm

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('data_generator.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def generate_data(size):
    """
    生成随机数据
    
    Args:
        size: 数据规模
    
    Returns:
        生成的数据数组
    """
    logger.info(f"开始生成{size}个随机数据...")
    start_time = time.time()
    
    # 生成随机数据 (0-999999)
    data = np.random.randint(0, 1000000, size, dtype=np.int32)
    
    end_time = time.time()
    logger.info(f"数据生成完成，耗时: {end_time - start_time:.2f}秒")
    logger.info(f"数据形状: {data.shape}")
    logger.info(f"数据类型: {data.dtype}")
    logger.info(f"数据占用内存: {data.nbytes / 1024 / 1024:.2f}MB")
    
    return data

def validate_data(data):
    """
    验证数据完整性
    
    Args:
        data: 数据数组
    
    Returns:
        验证是否通过
    """
    logger.info("开始验证数据...")
    
    # 检查数据类型
    if data.dtype != np.int32:
        logger.error(f"数据类型错误: {data.dtype}")
        return False
    
    # 检查数据范围
    min_val = data.min()
    max_val = data.max()
    logger.info(f"数据范围: {min_val} - {max_val}")
    
    # 检查是否有NaN值
    if np.isnan(data).any():
        logger.error("数据中包含NaN值")
        return False
    
    logger.info("数据验证通过")
    return True

def save_data(data, output_path):
    """
    保存数据为HDF5格式
    
    Args:
        data: 数据数组
        output_path: 输出文件路径
    """
    logger.info(f"开始保存数据到 {output_path}...")
    start_time = time.time()
    
    # 确保输出目录存在
    output_dir = os.path.dirname(output_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)
        logger.info(f"创建输出目录: {output_dir}")
    
    # 保存数据
    with h5py.File(output_path, 'w') as f:
        # 保存数据
        f.create_dataset('data', data=data, compression='gzip', compression_opts=9)
        
        # 保存元数据
        f.attrs['version'] = '1.0'
        f.attrs['timestamp'] = time.strftime('%Y-%m-%d %H:%M:%S')
        f.attrs['data_size'] = len(data)
        f.attrs['data_type'] = str(data.dtype)
        f.attrs['generator_version'] = '1.0'
    
    end_time = time.time()
    logger.info(f"数据保存完成，耗时: {end_time - start_time:.2f}秒")
    logger.info(f"文件大小: {os.path.getsize(output_path) / 1024 / 1024:.2f}MB")

def main():
    """
    主函数
    """
    parser = argparse.ArgumentParser(description='数据生成脚本')
    parser.add_argument('--output', type=str, default='data/50000000_data.h5', 
                        help='输出文件路径')
    parser.add_argument('--size', type=int, default=50000000, 
                        help='数据规模')
    parser.add_argument('--log-level', type=str, default='INFO', 
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help='日志级别')
    
    args = parser.parse_args()
    
    # 设置日志级别
    logger.setLevel(getattr(logging, args.log_level))
    
    try:
        # 生成数据
        data = generate_data(args.size)
        
        # 验证数据
        if not validate_data(data):
            logger.error("数据验证失败，退出")
            return 1
        
        # 保存数据
        save_data(data, args.output)
        
        logger.info("数据生成任务完成")
        return 0
        
    except Exception as e:
        logger.exception(f"执行过程中发生错误: {str(e)}")
        return 1

if __name__ == "__main__":
    exit(main())
