#!/usr/bin/env python3
"""
数据加载模块

用于加载生成的数据文件
"""

import os
import h5py
import logging
import numpy as np

logger = logging.getLogger(__name__)

def load_data(input_path):
    """
    加载HDF5格式的数据
    
    Args:
        input_path: 输入文件路径
    
    Returns:
        加载的数据数组
    """
    logger.info(f"开始加载数据文件: {input_path}")
    
    # 检查文件是否存在
    if not os.path.exists(input_path):
        logger.error(f"文件不存在: {input_path}")
        raise FileNotFoundError(f"文件不存在: {input_path}")
    
    # 加载数据
    try:
        with h5py.File(input_path, 'r') as f:
            # 检查文件结构
            if 'data' not in f:
                logger.error("文件中不存在'data'数据集")
                raise ValueError("文件中不存在'data'数据集")
            
            # 加载数据
            data = f['data'][:]
            
            # 将NumPy数组转换为Python列表，便于算法处理
            data = data.tolist()
            
            # 读取元数据
            version = f.attrs.get('version', '未知')
            timestamp = f.attrs.get('timestamp', '未知')
            data_size = f.attrs.get('data_size', len(data))
            
            logger.info(f"数据加载完成")
            logger.info(f"版本: {version}")
            logger.info(f"时间戳: {timestamp}")
            logger.info(f"数据大小: {data_size}")
            logger.info(f"数据类型: list")
            
            # 验证数据大小
            if len(data) != data_size:
                logger.error(f"数据大小不匹配: 期望 {data_size}, 实际 {len(data)}")
                raise ValueError(f"数据大小不匹配")
            
            return data
            
    except Exception as e:
        logger.exception(f"加载数据时发生错误: {str(e)}")
        raise

def validate_data_integrity(data, expected_size=None):
    """
    验证数据完整性
    
    Args:
        data: 数据列表
        expected_size: 期望的数据大小
    
    Returns:
        验证是否通过
    """
    logger.info("开始验证数据完整性...")
    
    # 检查数据类型
    if not isinstance(data, list):
        logger.error(f"数据类型错误: {type(data)}")
        return False
    
    # 检查数据大小
    if expected_size is not None and len(data) != expected_size:
        logger.error(f"数据大小错误: 期望 {expected_size}, 实际 {len(data)}")
        return False
    
    # 检查数据元素类型
    if data and not isinstance(data[0], int):
        logger.error(f"数据元素类型错误: {type(data[0])}")
        return False
    
    # 检查数据范围
    if data:
        min_val = min(data)
        max_val = max(data)
        logger.info(f"数据范围: {min_val} - {max_val}")
    
    logger.info("数据完整性验证通过")
    return True
